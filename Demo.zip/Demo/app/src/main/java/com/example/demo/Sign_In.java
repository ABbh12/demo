package com.example.demo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Sign_In extends AppCompatActivity {

    EditText edt_name,edt_passwprd,edt_email;
    Button sign_in;
    DatabaseReference reference;
    User user;
    String name,password,email;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign__in);
        srtLayoutReference();
    }

    private void srtLayoutReference() {
        edt_name=(EditText)findViewById(R.id.edt_name);
        edt_passwprd=(EditText)findViewById(R.id.edt_pass);
        edt_email=(EditText)findViewById(R.id.edt_email);
        sign_in=(Button)findViewById(R.id.btn_add);

        sign_in.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name=edt_name.getText().toString().trim();
                password=edt_passwprd.getText().toString().trim();
                email=edt_email.getText().toString().trim();
                check_validation();
            }
        });

    }
    private void check_validation() {
        if( name != null && name.length() > 0){
            if( password != null && password.length() > 0){
                if( email != null && email.length() > 0){
                        //insert data in firebase
                        insertdata();
                }else {
                    Toast.makeText(this,getString(R.string.enter_email), Toast.LENGTH_SHORT).show();
                }

            }else{
                Toast.makeText(this,getString(R.string.enter_password), Toast.LENGTH_SHORT).show();
            }
        }else {
            Toast.makeText(this,getString(R.string.enter_name), Toast.LENGTH_SHORT).show();
        }
    }

    private void insertdata() {
        user=new User();
        reference= FirebaseDatabase.getInstance().getReference().child("User");
        user.setName(name);
        user.setEmail(email);
        user.setPassword(password);
        reference.push().setValue(user);
        Toast.makeText(this, "Data Insert", Toast.LENGTH_SHORT).show();
        Intent i=new Intent(Sign_In.this,Home.class);
        startActivity(i);
        finish();

    }
}