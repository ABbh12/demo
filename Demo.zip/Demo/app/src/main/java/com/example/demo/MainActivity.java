package com.example.demo;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
    TextView sigin_in,login;
    EditText edt_email,edt_password;
    String email,password;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setLayoutReference();
    }

    private void setLayoutReference() {

        sigin_in=(TextView)findViewById(R.id.btn_sign_in);
        edt_email=(EditText)findViewById(R.id.txt_email);
        edt_password=(EditText)findViewById(R.id.txt_pass);
        login=(TextView)findViewById(R.id.login);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                email=edt_email.getText().toString().trim();
                password=edt_password.getText().toString().trim();
                check_validation();
            }
        });
        sigin_in.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(MainActivity.this,Sign_In.class);
                startActivity(i);
            }
        });
    }

    private void check_validation() {
        if( email != null && email.length() > 0){
            if( password != null && password.length() > 0){
                checkLogin();
            }else{
                Toast.makeText(this,getString(R.string.enter_password), Toast.LENGTH_SHORT).show();
            }
        }else {
            Toast.makeText(this,getString(R.string.enter_email), Toast.LENGTH_SHORT).show();
        }

    }

    private void checkLogin() {
        reference= FirebaseDatabase.getInstance().getReference().child("User");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                boolean check =false;
             for(DataSnapshot dataSnapshot:snapshot.getChildren()) {

                     User user = dataSnapshot.getValue(User.class);
                     String u_emai = user.getEmail();
                     String u_pass = user.getPassword();
                     if (u_emai.equals(email) && u_pass.equals(password)) {
                         check=true;
                     }

             }
                if(check) {
                    Intent i = new Intent(MainActivity.this, Home.class);
                    startActivity(i);
                    finish();
                } else {
                    Toast.makeText(MainActivity.this, "Invalid Email and Password", Toast.LENGTH_SHORT).show();
                }

             }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}